package jp.ac.waseda.cs.washi.samurai.insight;

import java.util.logging.Logger;

import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.mapping.MappingMesh;

public abstract class Insight {
	protected MappingMesh mesh;
	protected static final Logger logger = Logger.getLogger(Insight.class.getPackage().getName());
	
	public static final Direction[] validDirections = new Direction[] { Direction.DOWN,
			Direction.LEFT, Direction.RIGHT, Direction.UP };
	public static final Direction defaultDirection = Direction.UNKNOWN;
	
	public abstract void update();
	public void init(MappingMesh m){
		mesh = m;
	}

    protected Insight requireInsight(Insight s) {
    	return mesh.requireInsight(s);
    }
}
