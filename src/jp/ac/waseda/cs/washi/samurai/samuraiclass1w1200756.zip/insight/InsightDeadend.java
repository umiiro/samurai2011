package jp.ac.waseda.cs.washi.samurai.insight;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.ac.waseda.cs.washi.samurai.mapping.MappingField;

public class InsightDeadend extends Insight {

	public static final int defaultDistance = Integer.MAX_VALUE;
	
	private Map<MappingField, Integer> map = Collections.emptyMap();
	private ComputationThread computationThread = null;

	public int getDeadendDistance(MappingField f) {
		return map.containsKey(f) ? map.get(f) : defaultDistance;
	}

	@Override
	public void update() {
		if (map.isEmpty()) {
			if (computationThread == null) {
				computationThread = new ComputationThread();
				computationThread.start();
			} else if (!computationThread.isAlive()) {
				map = computationThread.getMap();
				computationThread = null;
			}
		}
	}
	
	private class ComputationThread extends Thread {
		private Set<MappingField> open = new HashSet<MappingField>();
		private Set<MappingField> next = new HashSet<MappingField>();
		private Set<MappingField> visited = new HashSet<MappingField>();
		private Map<MappingField, Integer> workingMap, freezedMap;
		public int maxDistance;
		
		public Map<MappingField, Integer> getMap() {
			return freezedMap;
		}
		
		public ComputationThread() {
			List<MappingField> fields = mesh.getFields();
			int numFields = fields.size();
			open = new HashSet<MappingField>();
			next = new HashSet<MappingField>();
			visited = new HashSet<MappingField>(numFields);
			workingMap = new HashMap<MappingField, Integer>(numFields);
			maxDistance = numFields * numFields;
		}
		
		private int findDeadend(MappingField start) {
			open.clear();
			open.add(start);

			visited.clear();

			for (int i = 0; i < maxDistance; i++) {
				next.clear();

				for (MappingField f : open) {
					Collection<MappingField> adj = f.getAdjacents();

					if (adj.size() == 1) {
						return i;
					}

					visited.add(f);
					
					next.addAll(adj);
				}

				next.removeAll(visited);
				
				Set<MappingField> swap;
				swap = open;
				open = next;
				next = swap;
			}		

			return Integer.MAX_VALUE;
		}
		
		@Override
		public void run() {
			long startTime = System.currentTimeMillis();
			
			for (MappingField f : mesh.getFields()) {
				workingMap.put(f, findDeadend(f));
			}
			
			freezedMap = Collections.unmodifiableMap(workingMap);
			logger.info("Deadend freeze: " + (System.currentTimeMillis() - startTime) + "ms");
		}
	}
}
