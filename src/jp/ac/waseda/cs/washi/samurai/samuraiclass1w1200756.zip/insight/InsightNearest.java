package jp.ac.waseda.cs.washi.samurai.insight;

import java.util.EnumMap;
import java.util.Map;

import jp.ac.waseda.cs.washi.samurai.api.BonusType;
import jp.ac.waseda.cs.washi.samurai.mapping.MappingField;
import jp.ac.waseda.cs.washi.samurai.mapping.MappingMesh;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;

public class InsightNearest extends Insight {
	private InsightShortestPath sp;
	public Map<BonusType, Integer> profits;

	@Override
	public void init(MappingMesh m) {
		super.init(m);
		sp = (InsightShortestPath)requireInsight(new InsightShortestPath());
		profits = new EnumMap<BonusType, Integer>(BonusType.class);
		profits.put(BonusType.BIG, 100);
		profits.put(BonusType.SHOGUN, 50);
		profits.put(BonusType.SMALL, 10);
		profits.put(BonusType.NONE, 0);
	}

	public Playable getNearestEnemy(Playable p, boolean offensive) {
		int minDistance = Integer.MAX_VALUE;
		Playable nearestPlayable = Playable.EMPTY;

		for (Playable ep : p.getEnemies()) {
			if (ep.isUnknown() || p.isOffensive(ep) != offensive)
				continue;

			int dist = sp.getShortestDistance(p.getField(), ep.getField());
			if (dist < minDistance) {
				minDistance = dist;
				nearestPlayable = ep;
			}
		}

		return nearestPlayable;
	}
	
	public MappingField getNearestBonus(Playable p) {
		MappingField pf = p.getField();
		int maxScore = 0;
		int minDistance = Integer.MAX_VALUE;
		MappingField bestField = MappingField.EMPTY;
		
		for (MappingField f : mesh.getFields()) {
			int distance = sp.getShortestDistance(pf, f);
			int score = profits.get(f.getBonus());

			if (score > maxScore || (score == maxScore && distance < minDistance)) {
				maxScore = score;
				minDistance = distance;
				bestField = f;
			}
		}
		
		return bestField;
	}

	@Override
	public void update() {
	}
}
