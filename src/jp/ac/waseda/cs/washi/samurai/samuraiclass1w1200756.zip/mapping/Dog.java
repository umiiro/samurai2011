/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.ac.waseda.cs.washi.samurai.mapping;

import java.util.HashSet;
import java.util.Set;

import jp.ac.waseda.cs.washi.samurai.api.Chara;
import jp.ac.waseda.cs.washi.samurai.api.CharaState;

/**
 *
 * @author kaito
 */
public class Dog extends Playable {

    private Samurai collegue;
    private Set<Samurai> enemies;

    public Dog(Chara c, MappingMesh m) {
        super(c, m);
        enemies = new HashSet<Samurai>();
    }

    @Override
    public boolean isOffensive(Playable p) {
        return (p instanceof Samurai) && (p.getState() == CharaState.SHOGUN);
    }

    @Override
    public Samurai getCollegue() {
        return collegue;
    }

    @Override
    public Set<Samurai> getEnemies() {
        return enemies;
    }

    public void setCollegue(Samurai p) {
        collegue = p;
    }

    public void addEnemy(Samurai p) {
        enemies.add(p);
    }
}
