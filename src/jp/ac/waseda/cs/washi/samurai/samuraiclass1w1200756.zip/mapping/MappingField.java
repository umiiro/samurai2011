/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.ac.waseda.cs.washi.samurai.mapping;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ac.waseda.cs.washi.samurai.api.BonusType;
import jp.ac.waseda.cs.washi.samurai.api.Direction;

/**
 * 
 * @author kaito
 */
public class MappingField extends MappingNode {
	public static final MappingField EMPTY;

	private Map<MappingField, Direction> adjacentDirection;
	private Map<Direction, MappingField> directionAdjacent;
	private List<MappingField> adjacents;
	private List<Direction> directions;
	private BonusType bonus;
	private List<Playable> playables;
	private int posX, posY;
	
	static {
		EMPTY = new MappingField(-1, -1);
		EMPTY.adjacentDirection = Collections.emptyMap();
		EMPTY.directionAdjacent = Collections.emptyMap();
		EMPTY.adjacents = Collections.emptyList();
		EMPTY.directions = Collections.emptyList();
		EMPTY.playables = Collections.emptyList();
		EMPTY.bonus = BonusType.NONE;
	}
	
	protected MappingField() {
		super(TYPE_FIELD);
	}

	public MappingField(int x, int y) {
		super(TYPE_FIELD);
		directionAdjacent = new EnumMap<Direction, MappingField>(Direction.class);
		adjacentDirection = new HashMap<MappingField, Direction>();
		adjacents = new ArrayList<MappingField>();
		directions = new ArrayList<Direction>();
		bonus = BonusType.NONE;
		posX = x;
		posY = y;
		playables = new ArrayList<Playable>();
	}

	public void setBonus(BonusType b) {
		bonus = b;
	}

	public BonusType getBonus() {
		return bonus;
	}

	public int getX() {
		return posX;
	}

	public int getY() {
		return posY;
	}

	public void connect(MappingField f, Direction d) {
		adjacentDirection.put(f, d);
		directionAdjacent.put(d, f);
		adjacents.add(f);
		directions.add(d);
	}

	public void enter(Playable p) {
		playables.add(p);
	}

	public void leave(Playable p) {
		playables.remove(p);
	}

	public List<Playable> getPlayables() {
		return playables;
	}

	public Collection<MappingField> getAdjacents() {
		return adjacents;
	}

	public Map<MappingField,Direction> getAdjDirMap() {
		return adjacentDirection;
	}

	public Collection<Direction> getDirections() {
		return directions;
	}
	
	public Map<Direction,MappingField> getDirAdjMap() {
		return directionAdjacent;
	}

	public void freezeConnection() {
		adjacentDirection = Collections.unmodifiableMap(adjacentDirection);
		directionAdjacent = Collections.unmodifiableMap(directionAdjacent);
		adjacents = Collections.unmodifiableList(adjacents);
		directions = Collections.unmodifiableList(directions);
	}
	
	@Override
	public String toString() {
		return "Field{X=" + posX + ",Y="+ posY + "}";
	}
}
