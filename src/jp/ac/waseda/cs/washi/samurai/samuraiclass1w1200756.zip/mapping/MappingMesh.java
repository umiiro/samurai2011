/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.ac.waseda.cs.washi.samurai.mapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ac.waseda.cs.washi.samurai.api.BonusType;
import jp.ac.waseda.cs.washi.samurai.api.Chara;
import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.Insight;

/**
 * 
 * @author kaito
 */
public class MappingMesh {

	public Direction[] validDirections = new Direction[] { Direction.DOWN,
			Direction.LEFT, Direction.RIGHT, Direction.UP };
	private List<MappingField> fields = Collections.emptyList();
	private Map<String, Insight> insights = new HashMap<String, Insight>();
	private List<MappingNode> nodes = Collections.emptyList();
	private List<Playable> playables = Collections.emptyList();
	private int remainingTime;
	private int width, height;

	public List<Direction> availableDirections(Playable p) {
		int x = p.getX();
		int y = p.getY();
		List<Direction> dirs = new ArrayList<Direction>();

		MappingNode node = getNodeAt(x, y);

		if (node instanceof MappingField) {
			for (Direction d : validDirections) {
				if (getNodeAt(x + d.dx, y + d.dy) instanceof MappingField) {
					dirs.add(d);
				}
			}
		}

		return dirs;
	}

	public Insight getInsight(String name) {
		return insights.get(name);
	}

	public MappingField getFieldAt(Playable p) {
		if (p.isUnknown()) {
			return MappingField.EMPTY;
		} else {
			try {
				return (MappingField) getNodeAt(p.getX(), p.getY());
			} catch (ClassCastException e) {
				throw new IllegalArgumentException();
			}
		}
	}

	public List<MappingField> getFields() {
		return fields;
	}

	public int getHeight() {
		return height;
	}

	public MappingNode getNodeAt(int x, int y) {
		if (x < 1 || y < 1 || x > width || y > height) {
			return MappingWall.OUT_OF_FIELD;
		} else {
			return nodes.get(y * width + x);
		}
	}

	public Playable getPlayable(Chara c) {
		for (Playable p : playables) {
			if (p.getChara() == c) {
				return p;
			}
		}
		throw new IllegalArgumentException();
	}

	public List<Playable> getPlayables() {
		return playables;
	}

	public int getRemainingTime() {
		return remainingTime;
	}

	public int getWidth() {
		return width;
	}

	public Insight requireInsight(Insight s) {
		String type = s.getClass().getName();
		if (!insights.containsKey(type)) {
			s.init(this);
			insights.put(type, s);
		}
		return insights.get(type);
	}

	public void update(jp.ac.waseda.cs.washi.samurai.api.Map m) {
		if (nodes.size() == 0) {
			allocateTree(m);
			connectFields();
			retriveChara(m);
		}

		updateBonus(m);
		updatePlayables();
		remainingTime = m.getRemainingTime();

		updateInsights();
	}

	private void allocateTree(jp.ac.waseda.cs.washi.samurai.api.Map map) {
		int x, y;
		MappingField tmp;

		width = map.getWidth();
		height = map.getHeight();
		nodes = new ArrayList<MappingNode>(width * height);
		fields = new ArrayList<MappingField>();

		for (y = 0; y < height; y++) {
			for (x = 0; x < width; x++) {
				if (map.isWall(x, y)) {
					nodes.add(MappingWall.OUT_OF_FIELD);
				} else {
					tmp = new MappingField(x, y);
					nodes.add(tmp);
					fields.add(tmp);
				}
			}
		}

		nodes = Collections.unmodifiableList(nodes);
		fields = Collections.unmodifiableList(fields);
	}

	private void connectFields() {
		int x, y;

		for (MappingField field : fields) {
			for (Direction d : validDirections) {
				x = field.getX();
				y = field.getY();

				MappingNode adj = getNodeAt(x + d.dx, y + d.dy);

				if (adj instanceof MappingField) {
					field.connect((MappingField) adj, d);
				}
			}
			field.freezeConnection();
		}
	}

	private void retriveChara(jp.ac.waseda.cs.washi.samurai.api.Map m) {
		ArrayList<Samurai> sams = new ArrayList<Samurai>();
		ArrayList<Dog> dogs = new ArrayList<Dog>();

		for (int i = 0; i < 4; i++) {
			Samurai s = new Samurai(m.getSamurai(i), this);
			Dog d = new Dog(m.getDog(i), this);
			s.setCollegue(d);
			d.setCollegue(s);
			sams.add(s);
			dogs.add(d);
		}

		for (Dog d : dogs) {
			for (Samurai s : sams) {
				if (s == d.getCollegue()) {
					continue;
				}
				d.addEnemy(s);
			}
		}

		for (Samurai s : sams) {
			for (Dog d : dogs) {
				if (d == s.getCollegue()) {
					continue;
				}
				s.addEnemy(d);
			}
		}

		playables = new ArrayList<Playable>();
		playables.addAll(sams);
		playables.addAll(dogs);
		playables = Collections.unmodifiableList(playables);
	}

	private void updateBonus(jp.ac.waseda.cs.washi.samurai.api.Map map) {
		for (MappingField f : fields) {
			BonusType b = map.getBonus(f.getX(), f.getY());
			f.setBonus(b);
		}
	}

	private void updatePlayables() {
		for (Playable p : playables) {
			p.updateNode();
		}
	}

	private void updateInsights() {
		for (Insight s : insights.values()) {
			s.update();
		}
	}
}
