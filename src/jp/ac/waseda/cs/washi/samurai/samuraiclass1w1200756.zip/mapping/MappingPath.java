package jp.ac.waseda.cs.washi.samurai.mapping;

public class MappingPath {

}
