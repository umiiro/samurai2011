/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.ac.waseda.cs.washi.samurai.mapping;

import java.awt.Point;
import java.util.Set;

import jp.ac.waseda.cs.washi.samurai.api.Chara;
import jp.ac.waseda.cs.washi.samurai.api.CharaState;
import jp.ac.waseda.cs.washi.samurai.api.CharaType;
import jp.ac.waseda.cs.washi.samurai.api.Direction;

/**
 *
 * @author kaito
 */
public abstract class Playable {
	
	public static final Playable EMPTY = new VoidPlayable();
    private MappingMesh mesh;
    private Chara delegate;
    private MappingField field;
    
    public Playable(Chara c, MappingMesh m) {
        mesh = m;
        delegate = c;
        field = MappingField.EMPTY;
    }
    
    public Chara getChara() {
        return delegate;
    }
    
    public boolean isEnemy(Playable p) {
        return getEnemies().contains(p);
    }
    
    public abstract Playable getCollegue();
    public abstract Set<? extends Playable> getEnemies();
    public abstract boolean isOffensive(Playable p);
    
    public MappingField getField() {
        return field;
        
    }
    
    public void updateNode() {
    	if (field != MappingField.EMPTY) {
    		field.leave(this);
    	}
        
        field = (MappingField)mesh.getFieldAt(this);
        
        if (field != MappingField.EMPTY) {
        	field.enter(this);
        }
    }
    
    public boolean isUnknown() {
    	return delegate.getX() < 0 &&
    			delegate.getY() < 0 &&
    			delegate.getState() == CharaState.INVISIBLE;
    }
    
    public Direction getDirection() {
        return delegate.getDirection();
    }

    public Point getLocation() {
        return delegate.getLocation();
    }

    public int getScore() {
        return delegate.getScore();
    }

    public CharaState getState() {
        return delegate.getState();
    }

    public int getStateRemainingTime() {
        return delegate.getStateRemainingTime();
    }
    
    public CharaType getType() {
        return delegate.getType();
    }

    public int getX() {
        return delegate.getX();
    }

    public int getY() {
        return delegate.getY();
    }
}
