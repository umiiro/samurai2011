/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.ac.waseda.cs.washi.samurai.mapping;

import java.util.HashSet;
import java.util.Set;

import jp.ac.waseda.cs.washi.samurai.api.Chara;
import jp.ac.waseda.cs.washi.samurai.api.CharaState;

/**
 *
 * @author kaito
 */
public class Samurai extends Playable {
    private Dog collegue;
    private Set<Dog> enemies;
    
    public Samurai(Chara c, MappingMesh m) {
        super(c, m);
        enemies = new HashSet<Dog>();
    }

    @Override
    public boolean isOffensive(Playable p) {
    	if (getState() == CharaState.SHOGUN && getStateRemainingTime() > 3) {
    		return isOffensiveInNormal(p) && (p.getScore() == 0);
    	} else {
    		return isOffensiveInNormal(p);
    	}
    }
    
    public boolean isOffensiveInNormal(Playable p) {
        return (p instanceof Dog) && isEnemy(p);
    }
    
    @Override
    public Dog getCollegue() {
        return collegue;
    }

    @Override
    public Set<Dog> getEnemies() {
        return enemies;
    }

    public void setCollegue(Dog p) {
        collegue = p;
    }

    public void addEnemy(Dog p) {
        enemies.add(p);
    }
}
