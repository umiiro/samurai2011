package jp.ac.waseda.cs.washi.samurai.mapping;

import java.awt.Point;
import java.util.Collections;
import java.util.Set;

import jp.ac.waseda.cs.washi.samurai.api.Chara;
import jp.ac.waseda.cs.washi.samurai.api.CharaState;
import jp.ac.waseda.cs.washi.samurai.api.CharaType;
import jp.ac.waseda.cs.washi.samurai.api.Direction;


public class VoidPlayable extends Playable {
	
	public VoidPlayable() {
		super(null, null);
	}

	@Override
	public Playable getCollegue() {
		return this;
	}

	@Override
	public Chara getChara() {
		return null;
	}

	@Override
	public boolean isEnemy(Playable p) {
		return false;
	}

	@Override
	public void updateNode() {
	}

	@Override
	public boolean isUnknown() {
		return true;
	}

	@Override
	public Direction getDirection() {
		return Direction.UNKNOWN;
	}

	@Override
	public Point getLocation() {
		return new Point(getX(), getY());
	}

	@Override
	public int getScore() {
		return 0;
	}

	@Override
	public CharaState getState() {
		return null;
	}

	@Override
	public int getStateRemainingTime() {
		return 0;
	}

	@Override
	public CharaType getType() {
		return null;
	}

	@Override
	public int getX() {
		return getField().getX();
	}

	@Override
	public int getY() {
		return getField().getY();
	}

	@Override
	public Set<? extends Playable> getEnemies() {
		return Collections.emptySet();
	}

	@Override
	public boolean isOffensive(Playable p) {
		return false;
	}

}