package jp.ac.waseda.cs.washi.samurai.personality;

import java.util.logging.Level;

import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.InsightNearest;
import jp.ac.waseda.cs.washi.samurai.insight.InsightShortestPath;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyAcross;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyFierce;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyRobber;

public class DogDefault extends Personality {
	private StrategyAcross across = new StrategyAcross();
	private StrategyFierce fierce = new StrategyFierce();
	private StrategyRobber robber = new StrategyRobber();
	private InsightNearest nr;
	private InsightShortestPath sp;
	
	@Override
	public void vote(Playable p) {
		if (logger.isLoggable(Level.FINE)) {
			logger.info("===== DogDefault =====");
		}
		
		Playable c = p.getCollegue();
		Playable ce = nr.getNearestEnemy(c, true);
		if (sp.getShortestDistance(c, ce) < 3) {
			if (sp.getShortestDistance(p, p.getCollegue()) == 1) {
				headquater.getBallot().submitElement(Direction.UNKNOWN, 10d);
			} else {
				across.vote(p);
			}
		} else if (p.getScore() > 0) {
			if (mesh.getRemainingTime() < 200) {
				across.vote(p);
				return;
			}
			Playable ep = nr.getNearestEnemy(p, false);
			if (sp.getShortestDistance(p, ep) < 2) {
				fierce.vote(p);
			} else {
				across.vote(p);
			}
		} else {
			robber.vote(p);
		}
		
		if (logger.isLoggable(Level.FINE)) {
			logger.info("===== /DogDefault =====");
		}
	}

	@Override
	public void init() {
		nr = (InsightNearest)mesh.requireInsight(new InsightNearest());
		sp = (InsightShortestPath)mesh.requireInsight(new InsightShortestPath());
		across.setHeadquater(headquater);
		fierce.setHeadquater(headquater);
		robber.setHeadquater(headquater);
	}
}
