package jp.ac.waseda.cs.washi.samurai.personality;

import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.InsightShortestPath;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;

public class DogSimple extends Personality {
	private InsightShortestPath sp;
	private Playable target;
	
	@Override
	public void vote(Playable p) {
		Direction dir = sp.getShortestDirection(p, target);
		ballot.submitElement(dir, 1d);
	}
	
	public void setTarget(Playable p) {
		target = p;
	}

	@Override
	public void init() {
		sp = (InsightShortestPath)mesh.requireInsight(new InsightShortestPath());
	}
}
