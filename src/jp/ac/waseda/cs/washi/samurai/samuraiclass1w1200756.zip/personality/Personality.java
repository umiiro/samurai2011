package jp.ac.waseda.cs.washi.samurai.personality;

import java.util.logging.Logger;

import jp.ac.waseda.cs.washi.samurai.main.BallotBox;
import jp.ac.waseda.cs.washi.samurai.main.Headquater;
import jp.ac.waseda.cs.washi.samurai.mapping.MappingMesh;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;

public abstract class Personality {
	protected static final Logger logger = Logger.getLogger(Personality.class.getPackage().getName());
	protected Headquater headquater;
	protected MappingMesh mesh;
	protected BallotBox ballot;

	public void setHeadquater(Headquater hq) {
		headquater = hq;
		mesh = hq.getMappingMesh();
		ballot = headquater.getBallot();
	}
	
	public void setBallot(BallotBox ballot) {
		this.ballot = ballot;
	}

	public abstract void init();
	public abstract void vote(Playable p);
}
