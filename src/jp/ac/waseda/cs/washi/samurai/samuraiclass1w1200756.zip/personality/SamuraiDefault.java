package jp.ac.waseda.cs.washi.samurai.personality;

import java.util.logging.Level;

import jp.ac.waseda.cs.washi.samurai.api.CharaState;
import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.InsightMostProfitable;
import jp.ac.waseda.cs.washi.samurai.insight.InsightNearest;
import jp.ac.waseda.cs.washi.samurai.insight.InsightShortestPath;
import jp.ac.waseda.cs.washi.samurai.main.BallotBox;
import jp.ac.waseda.cs.washi.samurai.main.DirectionVector;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyAcross;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyBounce;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyCoward;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyGreedy;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyRemote;
import jp.ac.waseda.cs.washi.samurai.strategy.StrategyRobber;

public class SamuraiDefault extends Personality {

	private InsightNearest nr;
	private InsightShortestPath sp;
	private InsightMostProfitable mp;
	private StrategyBounce bounce = new StrategyBounce();
	private StrategyCoward coward = new StrategyCoward();
	private StrategyGreedy greedy = new StrategyGreedy();
	private StrategyRobber robber = new StrategyRobber();
	private StrategyRemote remote = new StrategyRemote();
	private StrategyAcross across = new StrategyAcross();
	
	@Override
	public void vote(Playable p) {
		if (logger.isLoggable(Level.FINE)) {
			logger.info("===== SamuraiDefault =====");
		}
		
		BallotBox ballot = headquater.getBallot();
		ballot.fair();
		
		if (p.getState() == CharaState.INVISIBLE) {
			if (logger.isLoggable(Level.FINE)) {
				logger.info("A");
			}
			bounce.vote(p);
			remote.vote(p);
			return;
		}

		int distanceE = sp.getShortestDistance(p, nr.getNearestEnemy(p, false));
		int distanceO = sp.getShortestDistance(p, nr.getNearestEnemy(p, true));
		if (p.getState() == CharaState.SHOGUN) {
			if (logger.isLoggable(Level.FINE)) {
				logger.info("B");
			}
			if (distanceE < 2) {
				robber.vote(p);
			} else if (p.getStateRemainingTime() < 5 && distanceO < 2) {
				headquater.getBallot().submitElement(Direction.UNKNOWN, 10d);
				bounceAuto(p);
			} else {
				greedyAuto(p);
			}
		} else {
			if (logger.isLoggable(Level.FINE)) {
				logger.info("C");
			}
			if (distanceO < 3) {
				bounceAuto(p);
			} else {
				greedyAuto(p);
			}
		}

		if (logger.isLoggable(Level.FINE)) {
			logger.info("===== /SamuraiDefault =====");
		}
	}
	
	private void greedyAuto(Playable p) {
		logger.info(mp.getScore(p).toString());
		if (sp.getShortestDistance(p, p.getCollegue()) == 1) {
			headquater.getBallot().submitElement(Direction.UNKNOWN, 10d);
		} else if (mp.isFailed(p)) {
			remote.vote(p);
		} else {
			greedy.vote(p);
		}
	}
	
	private void bounceAuto(Playable p) {
		if (p.getField().getAdjacents().size() > 2) {
			ballot.withWeight(3d);
			greedyAuto(p);
		}
		ballot.fair();
		bounce.vote(p);
		ballot.withWeight(10d);
		coward.vote(p);
	}

	@Override
	public void init() {
		nr = (InsightNearest)mesh.requireInsight(new InsightNearest());
		sp = (InsightShortestPath)mesh.requireInsight(new InsightShortestPath());
		mp = (InsightMostProfitable)mesh.requireInsight(new InsightMostProfitable());
		bounce.setHeadquater(headquater);
		coward.setHeadquater(headquater);
		greedy.setHeadquater(headquater);
		robber.setHeadquater(headquater);
		remote.setHeadquater(headquater);
		across.setHeadquater(headquater);
	}
}
