package jp.ac.waseda.cs.washi.samurai.strategy;

import java.util.logging.Logger;

import jp.ac.waseda.cs.washi.samurai.insight.Insight;
import jp.ac.waseda.cs.washi.samurai.main.BallotBox;
import jp.ac.waseda.cs.washi.samurai.main.Headquater;
import jp.ac.waseda.cs.washi.samurai.mapping.MappingMesh;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;


public abstract class Strategy {

    private Headquater headquater;
    protected MappingMesh mesh;
    protected BallotBox ballot;
    protected static final Logger logger = Logger.getLogger(Strategy.class.getPackage().getName());
    
    public void setHeadquater(Headquater hq) {
    	headquater = hq;
    	mesh = headquater.getMappingMesh();
    	ballot = headquater.getBallot();
    }
    
    protected Insight requireInsight(Insight s) {
    	return mesh.requireInsight(s);
    }

    public abstract void vote(Playable c);
}
