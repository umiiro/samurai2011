package jp.ac.waseda.cs.washi.samurai.strategy;

import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.InsightShortestPath;
import jp.ac.waseda.cs.washi.samurai.main.Headquater;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;

public class StrategyAcross extends Strategy {
	private InsightShortestPath sp;

	@Override
	public void setHeadquater(Headquater hq) {
		super.setHeadquater(hq);
		sp = (InsightShortestPath)requireInsight(new InsightShortestPath());
	}

	@Override
	public void vote(Playable p) {
		logger.info("d:"+sp.getShortestDistance(p.getField(), p.getCollegue().getField()));
		Direction d = sp.getShortestDirection(p, p.getCollegue());
		int distance = sp.getShortestDistance(p, p.getCollegue());
		if (distance > 0) {
			ballot.submitElement(d, 1d);
		}
	}
}