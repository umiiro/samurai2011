package jp.ac.waseda.cs.washi.samurai.strategy;

import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.InsightNearest;
import jp.ac.waseda.cs.washi.samurai.insight.InsightShortestPath;
import jp.ac.waseda.cs.washi.samurai.main.Headquater;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;

public class StrategyFierce extends Strategy {
	private InsightShortestPath sp;
	private InsightNearest nr;

	@Override
	public void setHeadquater(Headquater hq) {
		super.setHeadquater(hq);
		nr = (InsightNearest)requireInsight(new InsightNearest());
		sp = (InsightShortestPath)requireInsight(new InsightShortestPath());
	}

	@Override
	public void vote(Playable p) {
		Playable nearest = nr.getNearestEnemy(p, false);
		Direction d;
		
		d = sp.getShortestDirection(p.getField(), nearest.getField());
		
		ballot.submitElement(d, 1d);
	}
}