package jp.ac.waseda.cs.washi.samurai.strategy;

import java.util.Map;
import java.util.logging.Level;

import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.InsightMostProfitable;
import jp.ac.waseda.cs.washi.samurai.main.DirectionVector;
import jp.ac.waseda.cs.washi.samurai.main.Headquater;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;

public class StrategyGreedy extends Strategy {
	private InsightMostProfitable mp;

	@Override
	public void setHeadquater(Headquater hq) {
		super.setHeadquater(hq);
		mp = (InsightMostProfitable)requireInsight(new InsightMostProfitable());
	}

	@Override
	public void vote(Playable p) {
		long startTime = System.currentTimeMillis();
		DirectionVector dv = new DirectionVector();

		for (Map.Entry<Direction,Integer> e : mp.getScore(p).entrySet()) {
			dv.put(e.getKey(), (double)e.getValue());
		}
		
		dv.normalize();
		ballot.submit(dv);
		
		if (logger.isLoggable(Level.FINEST)) {
			logger.finest("Greedy: " + dv);
		}

		if (logger.isLoggable(Level.FINE)) {
			logger.fine("Greedy: " + (System.currentTimeMillis() - startTime) + "ms");
		}
	}
}