package jp.ac.waseda.cs.washi.samurai.strategy;

import jp.ac.waseda.cs.washi.samurai.api.Direction;
import jp.ac.waseda.cs.washi.samurai.insight.InsightPrimaryPlayable;
import jp.ac.waseda.cs.washi.samurai.insight.InsightShortestPath;
import jp.ac.waseda.cs.washi.samurai.main.Headquater;
import jp.ac.waseda.cs.washi.samurai.mapping.Playable;

public class StrategyRobber extends Strategy {
	private InsightShortestPath sp;
	private InsightPrimaryPlayable pp;

	@Override
	public void setHeadquater(Headquater hq) {
		super.setHeadquater(hq);
		sp = (InsightShortestPath)requireInsight(new InsightShortestPath());
		pp = (InsightPrimaryPlayable)requireInsight(new InsightPrimaryPlayable());
	}

	@Override
	public void vote(Playable p) {
		Playable best = pp.getPrimaryEnemy(p, false);
		Direction d = sp.getShortestDirection(p, best);
		ballot.submitElement(d, 1d);
	}
}